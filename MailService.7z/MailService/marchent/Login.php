<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST"); //header used to insert data
header("Content-Type: application/json");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

require "../Database.php";
require "../validation.php";


date_default_timezone_set("Asia/Karachi");


class Login extends Database
{
private $email;
private $password;

function __construct($email,$pass)
{
    $this->email = $email;
    $this->password = $pass;

}

function login()
{
    $sql = "SELECT *FROM marchent WHERE Email = '{$this->email}' AND UserPassword= '{$this->password}' ";
    $con = self::build_connection();
    $res = $con->query($sql) or die();
    if($res->num_rows>0)
    {
        
        ////

 
    // Create token header as a JSON string
     $header = json_encode(['typ' => 'JWT', 'alg' => 'HS256']);
     $sql = "SELECT Mid FROM marchent WHERE Email = '{$this->email}' ";
     $con = self::build_connection();
     $res = $con->query($sql) or die('At Jwt Query Not Run');
     $id  = $res->fetch_assoc();
     $Mid   = $id['Mid'];
      

     // Create token payload as a JSON string
     $payload = json_encode(['email' =>$this->email ,'UserId'=>$Mid]);

     // Encode Header to Base64Url String
     $base64UrlHeader = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($header));

     // Encode Payload to Base64Url String
     $base64UrlPayload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($payload));

     // Create Signature Hash
     $rand = rand(111111,999999);
     $signature = hash_hmac('sha256', $base64UrlHeader . "." . $base64UrlPayload, $rand, true);

     // Encode Signature to Base64Url String
     $base64UrlSignature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));

     // Create JWT
     $jwt = $base64UrlHeader . "." . $base64UrlPayload . "." . $base64UrlSignature;

        /////
        $sql = "UPDATE marchent SET status = 0, token ='$jwt' WHERE Email = '{$this->email}' ";
        $con = self::build_connection();
        $res = $con->query($sql) or die("Update Query Error");
        http_response_code(200);
        $msg = array('Token'=>$jwt);
        echo json_encode($msg);
    }
    else
    {
        $msg = array("Status"=>"404","Message"=>"Not Exists");
        echo json_encode($msg);
    }
}


}

$data = json_decode(file_get_contents("php://input"),true);
$email = $data['email'];
$pass = $data['pass'];

$obj = new Login($email,$pass);
$obj->login();













?>