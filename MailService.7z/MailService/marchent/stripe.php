<?php
require "../Database.php";

$db = new Database();
    
$header = getallheaders();
$key=$header['Authorization']; 


date_default_timezone_set("Asia/Karachi");
    //Input Provided By Postman in Json Form

$input  = json_decode(file_get_contents("php://input"),true);

//Taking Inputs in References
$cardN  = $input['number'];
$expMon = $input['expMonth'];
$expY   = $input['expYear'];
$cvc    = $input['cvc'];
$token  = $input['token'];
$amount1 = $input['amount'];
$amount = $input['amount'];
$dollar = $amount/100;


$con = $db->build_connection();
$sql = "Select Mid,Name From marchent WHERE token='{$token}' And now() <= date_add(update_at,interval 15 minute)";
$run = $con->query($sql) or die("May be Token Expire");


if($run->num_rows>0)
$arr = $run->fetch_assoc();
else
die(json_encode(array("Status"=>"404","Message"=>"Token Expire")));



$mid = $arr['Mid'];
$cardName = $arr['Name'];






    $data =  [
                'card[number]' => $cardN,
                'card[exp_month]' => $expMon,
                'card[exp_year]' => $expY,
                'card[cvc]' => $cvc
            ];

    
    $stripTokenResponse = $db->getStripeToke($data);
    $stripTokenRes = json_decode($stripTokenResponse);
    $stripToken =  $stripTokenRes->id;
    $addBalance = $db->charge($stripToken,$amount);
    if($addBalance){


         $con = $db->build_connection() or die("Message: Connection Failed");
         $sql = " INSERT INTO `carddetail`(`Card-Holder`, `CardNumber`, `cvc`, `expire_month`, `expire_year`, `Mid`,`amount`) 
         VALUES ('{$cardName}','{$cardN}','{$cvc}','{$expMon}','{$expY}','{$mid}','{$dollar}')";
         $run = $con->query($sql) or Die(json_encode(array("Status"=>"404")));
         $msg = array("Status"=>"200","Message"=>"Successfully Credit Inserted");
        
    }

    
    
    ?>