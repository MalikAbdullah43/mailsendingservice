<?php
require "../Database.php";

$db= new Database();
    

    // add in stripe api
$input = json_decode(file_get_contents("php://input"),true);
$token = $input['token'];
echo $token;

    $data =  [
                'card[number]' => $input['number'],
                'card[exp_month]' => $input['expMonth'],
                'card[exp_year]' => $input['expYear'],
                'card[cvc]' => $input['cvc']
            ];

    $amount = 500;
    $stripTokenResponse = $db->getStripeToke($data);
    $stripTokenRes = json_decode($stripTokenResponse);
    $stripToken =  $stripTokenRes->id;
    $addBalance = $db->charge($stripToken,$amount);
    if($addBalance){


      
        echo json_encode(array("Message"=>"Okay is EveryThing"));
    }

    
    
    ?>