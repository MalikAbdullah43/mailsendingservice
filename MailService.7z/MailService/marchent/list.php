<?php

header('Content_type: Application/jason');
header('Access-Control-Allow-Origin:*');;
header('Access-Control-Method:POST');

require '../Database.php';


$db = new Database();                      // Creating object of  Database Class
$row = $db->fetch_list("marchent");        // Call Function to Fetch all data of Marchent table  
echo json_encode($row);                    // Encode the json formate and show data

?>