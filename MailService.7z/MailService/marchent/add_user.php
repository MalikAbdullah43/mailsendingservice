<?php

require "../Database.php";
require "../validation.php";

header('Content-Type:application/json');
header('Access-Control-Allow-Origin:*');
header('Access-Control-Allow-Methods:POST');
header('Access-Control-Allow-Headers:Access-Control-Allow-Headers,Content_Type,Access-Control-Allow-Methods,Authorization,X-Requested-With');

class User extends Database
{
     private $token;
     function __construct($token)
     {
            $this->token= $token;
     }
    public function addUser()
    {



        $con= self::build_connection();
        $sql = "select  Mid from marchent where token = '{$this->token}' AND now() <= date_add(update_at,interval 15 minute) ";
        $res = $con->query($sql) or die(json_encode(array("Status:"=>"404","Message"=>"Not Found")));
        if($res){
        if($res->num_rows>0)
        {
            $id = $res->fetch_assoc();
            $mid=$id['Mid'];
            $data  = json_decode(file_get_contents("php://input"),true);
            $name  =  $data['name'];
            $gender = $data['gender'];
            $pass = $data['pass'];
            $email = $data['email'];
            $forgetP= $data['forgetP'];
            $emailP= $data['emailP'];
            $reqVP= $data['reqVP'];
            $vBIllP= $data['vBillP'];
            $payBillP=$data['payBillP'];
            $image = $data['image'];
            echo $email;

            $sql = "INSERT INTO seconduser(Name,Gender,Userpassword,Email,Image,Mid,ForgP,emPer,reqView,vBill,PayP) 
            VALUES('{$name}','{$gender}','{$pass}','{$email}','{$image}','{$mid}','{$forgetP}','{$emailP}','{$reqVP}','{$vBIllP}','{$payBillP}')";
            $con = self::build_connection();
            $res = $con->query($sql) or die(json_encode(array("Status"=>"401","Message"=>"Insert Query Not Run")));
            if($res)
            {
               echo json_encode(array("Status"=>"200"));
            }


        }}
        else
        {
            echo json_encode(array("Status"=>"502","Message"=>"Invalid Request"));
            http_response_code(502);
        }
    }





}


$data  = json_decode(file_get_contents("php://input"),true);
$token = $data['token'];
$obj = new User($token);
$obj->addUser();


?>