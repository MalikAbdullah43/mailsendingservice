<?php
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
    header("Content-Type: Application/json");
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Methods: post");
    header('Access-Control-Allow-Headers: Content-Type,Access-Control-Allow-Methods,Access-Control-Allow-Headers,Authorization,X-Requested-With');

    require "../validation.php";
    require "../Database.php";
    
    class Signup extends Database{
        /**
         * Function to get the information through the postman
         */
        function get_data()
        {
            $data = json_decode(file_get_contents("php://input"),true);   //decide input request parameters and store them in an array.
            
            
            $name     = $data["name"];
            $password = $data["password"];
            $gender   = $data["gender"];
            $email    = $data["email"];
            $image    = $data["image"];
        /////


        $image_name = ""; //declaring the image name variable

        $image_name = time(). ".jpg"; //Giving new name to image.

        $image_upload_dir = $_SERVER['DOCUMENT_ROOT'].'/mailservice/image/'.$image_name; //Set the path where we need to upload the image.
        $flag = file_put_contents($image_upload_dir, base64_decode($image));

        /////
            
            $parameter=array($name,$gender,$password,$email,$flag); //store all data in array(parameter)

            
            if($parameter[0]=="" || $parameter[1]=="" || $parameter[2]=="" || $parameter[3]=="" ||$parameter[4] = "")

                return false;
            else
               return $parameter;
            
        }
        /**
         * Function to validate request input.
         */
        function validation($parameter){
            $che=true;
            $obj=new Validate();                                                   
            if(!$obj->name_validate($parameter[0]))  { $che=false; }   // validating name                                                            
            if(!$obj->email_validate($parameter[3]))  { $che=false; }   // validating email                                           
            if(!$obj->password_validate($parameter[2]))  { $che=false; }  // validating password
            return $che;
        }
        /**
         * function to insert data in data base after successful signup by the user
         */
        function insert_data($parameter)
        {
            if(self::search_employ_by_mail($parameter[3])) //checking whether user already exists or not
            {
                
                echo json_encode(array('Message'=>'User Already Exist With This Mail','status'=>"409"));  //status code 409 because user data added successfuly
                http_response_code(409);
            }
            else
            {
                $tableName = "marchent";
                self::insert($tableName,$parameter);  //insert data for new user

                $sql = "SELECT Mid FROM marchent WHERE Email='{$parameter[3]}'";
                $con = self::build_connection();
                $res  = $con->query($sql) or die();
                $id  = $res->fetch_assoc();
                $Mid   = $id['Mid'];
            echo json_encode(array('Sign Up Status'=>array('signUp'=>'Enjoy Free 100$','Your Id '=>$Mid),'Message'=>'SignUp Successfully :','status'=>"201",));  //status code 201 because user data added successfuly
                http_response_code(201);
            }
        }
    }



//Main Code///

    $obj = new Signup();    //create object signup class 
    $p1  = $obj->get_data();   //function call and get array


    if(!$p1)
    {      //check get_data return true or false
        echo json_encode(array('Message'=>'Please Fill All the Fields :','status'=>"422")); //status code 422 because user not fill important field
        http_response_code(422);
    }
    else
    {
        if($obj->validation($p1))
                $obj->insert_data($p1);
        else
                http_response_code(422);   //status code 422 because user enter invalid data
    
    }
?>









