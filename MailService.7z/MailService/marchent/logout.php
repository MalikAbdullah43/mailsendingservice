<?php
require '../Database.php'; 

$data = json_decode(file_get_contents("php://input"),true);
$token  = $data['token'];
$obj = new Database();
$obj->logout($token);

?>