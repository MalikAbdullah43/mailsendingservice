-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 17, 2021 at 03:53 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `emp`
--  


CREATE DATABASE mailservice;
USE mailservice;

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--
-- --------------------------------------------------------

--
-- Table structure for table `marchent`
--

CREATE TABLE `marchent` (
  `Mid` int(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) NOT NULL,
  `Gender` varchar(255) DEFAULT NULL,
  `UserPassword` varchar(255) NOT NULL,
  `Email` varchar(255) UNIQUE KEY NOT NULL,
  `Image` binary DEFAULT NULL,
  `otp` varchar(11) DEFAULT NULL,
  `status` varchar(11) DEFAULT NULL,
  `create_at` TIMESTAMP  current_timestamp(),
  `update_at` TIMESTAMP DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `marchent`
--
INSERT INTO `marchent` (`Name`,`Gender`, `UserPassword`,`Email`) VALUES
('Muhammad Usama', 'MALE', 'malik123','m.usamayounas669@gmail.com'),
('Waqas','MALE', 'malik1234','waqas@gamil.com');


--
--Table structure for table `SecondUser`
--
CREATE TABLE `SecondUser` (
  `Uid` int(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) NOT NULL,
  `Gender` varchar(255) DEFAULT NULL,
  `UserPassword` varchar(255) NOT NULL,
  `Email` varchar(255) UNIQUE KEY NOT NULL,
  `Image` BLOB DEFAULT NULL,
  `otp` varchar(11) DEFAULT NULL,
  `status` varchar(11) DEFAULT NULL,
  `Mid` int(11),
  FOREIGN KEY (Mid) REFERENCES marchent(Mid),
  `ForgP`  BOOLEAN DEFAULT 0,
  `emPer`  BOOLEAN DEFAULT 0,
  `reqView`BOLEAN DEFAULT 0,
  `vBill`  BOOLEAN DEFAULT 0,
  `PayP`   BOOLEAN DEFAULT 0,
  `create_at` TIMESTAMP,
  `update_at` TIMESTAMP NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



--DUMPING DATA FOR seconduser

INSERT INTO `seconduser` (`Name`,`Gender`, `UserPassword`,`Email`,`Mid`) VALUES
('Muhammad Usama', 'MALE', 'malik123','m.usamayounas669@gmail.com','1'),
('Waqas','MALE', 'malik1234','waqas@gamil.com','2'); 

--Mail List Table
CREATE TABLE `MailRecord` (
  `MailId` int(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) NOT NULL,
  `Email` varchar(255) UNIQUE KEY NOT NULL,
  `Mid` int(11),
   FOREIGN KEY (Mid) REFERENCES marchent(Mid),
  `Status` varchar(255) NOT NULL,
  `create_at` TIMESTAMP,
  `update_at` TIMESTAMP NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) 

--CardData
CREATE TABLE `Carddetail` (
  `CardId` int(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
  `Card-Holder` varchar(255) NOT NULL,
  `Mid` int(11),
   FOREIGN KEY (Mid) REFERENCES marchent(Mid),
  `Status` varchar(255) NOT NULL,
  `create_at` TIMESTAMP,
  `update_at` TIMESTAMP NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) 


--CREATE TABLE FOR Admin
CREATE TABLE `Admin` (
  `Aid`   int(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
  `Aname` varchar(255) NOT NULL,
  `create_at` TIMESTAMP,
  `update_at` TIMESTAMP NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) 


COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
