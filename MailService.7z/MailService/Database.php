<?php 

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require "../vendor/stripe/stripe-php/init.php";

class Database{

    public function build_connection(){     //build sql database connection 
        $conn = new mysqli("localhost","root","","mailservice");
        if ($conn->connect_error){
            echo "Database Connection Error";
        }
        else{
            
            return $conn;
        }
        
    }
    public function close_connection($conn){   //close database connection
        $conn->close();
    }

    /**
     * Function to insert marchent or seconduser in database.
     * 
     */
    function insert($tableName,$perameter){
        


        if ($tableName == "marchent")
        {
            $innerPera = "Name,Gender,UserPassword,email,image";
        }
        else
        {
            $innerPera = "Name,Gender,UserPassword,Email,image,Mid";
        }
        ////
       
        
        $Str = implode("','",$perameter);
        $mstr = "'".$Str."'";
        $conn = self::build_connection();
        $q = "insert into $tableName($innerPera) values($mstr)";
        $conn->query($q);
        self::close_connection($conn);
    }

    /**
     * This function is used to fetch users from table.
     */


    /**
     * This function is used to select user from table with the specific cnic.
     */
    function search_employ_by_mail($email)        // searching employee by cnic
    {   
        $conn = self::build_connection();
        $q = "select *from marchent WHERE email='{$email}'";
        $result = $conn->query($q);
        
        self::close_connection($conn);

        if($result->num_rows > 0 ){ return true;}

        else return false;
    }

    /**
     * This functioon is used to search employee with specific CNIC and name.
     */
    // function searchEmployee($tableName,$Name,$CNIC){
    //     $conn = self::build_connection();
    //     $N = "'$Name'";
    //     $C = "'$CNIC'";
    //     $q = "select * from $tableName where CNIC = $C and Name = $N";
    //     $result = $conn->query($q);
    //     $row = $result->fetch_assoc();
    //     self::close_connection($conn);
    //     return $row;
    // }




    ////Stripe Integration Function
    public function getStripeToke($data){
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_URL => 'https://api.stripe.com/v1/tokens',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FRESH_CONNECT => true,
            CURLOPT_POSTFIELDS => http_build_query($data),
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer sk_test_51JoSiMJlKYLW7VKGZv2SqrV0s3BDGzAEAp6Sg6DCvu53mmzw8JFqJ7yvuWuIN3SP7ok1EvjAx4GHztEfCE26tjiC00EwmnSYRM',
                'Content-type: application/x-www-form-urlencoded',
            ]
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    public function charge($token,$amount){
        $stripe = new \Stripe\StripeClient(
            'sk_test_51JoSiMJlKYLW7VKGZv2SqrV0s3BDGzAEAp6Sg6DCvu53mmzw8JFqJ7yvuWuIN3SP7ok1EvjAx4GHztEfCE26tjiC00EwmnSYRM'
        );
        $stripe->charges->create([
            'amount' => $amount,
            'currency' => 'usd',
            'source' => $token,
            'description' => 'balance top up',
        ]);

        return $stripe;
        
    }
   
}

?>
